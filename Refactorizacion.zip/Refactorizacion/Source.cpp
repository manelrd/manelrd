#include <iostream>
#include <string>
#include <Windows.h>
#include <cstdlib>
#include <conio.h>
#include <MMSystem.h>
#include <time.h>
#include <ctime>
#include <stdlib.h>

using namespace std;

int respuesta;
int eleccion;
int da�o_random_enemigo;
//Ataques de heroe
int Ferran = 30;
int Olmo = 15;
int Koke = 20;

//Heroe
int vida_heroe = 100;
string nombre_heroe;
bool heroe_vivo = true;

//Enemigo_01
int Vida_Enemigo_1 = 60, Da�o_enemigo_1;
string nombre_enemigo_1 = "Luis";
bool enemigo01_vivo = true;

//Enemigo_02
int vida_enemigo_2 = 60, Da�o_enemigo_2;
string nombre_enemigo_2 = "Enrique";
bool enemigo02_vivo = true;

void empezar() {
    cout << "Es hora de darle nombre al heroe, como se llamara?\n";
    cin >> nombre_heroe;
    cout << "Tu heroe se llamara " << nombre_heroe << "\n";
    cout << "Tienes dos duros enemigos por delante \n";
}

bool enemigoVivo(bool& VidaEnemigo, string nombreEnemigo) {
    if (VidaEnemigo <= 0) {
        cout << "\n";
        cout << "Has matado a " << nombreEnemigo << "\n";
        cout << "\n";
        return false;
    }
    else {
        return true;
    }
}


int eleccionEnemigo() {
    cout << "Elige uno de ellos [1](Luis) o [2](Enrique):  ";
    cin >> eleccion;
    return eleccion;
}


void AtaqueHeroe() {
    if ((eleccion == 1) && (enemigo01_vivo == true)) {
        cout << "Que ataque usaras? (1)Ferran (2)Olmo (3)Koke  ";
        cin >> respuesta;
        switch (respuesta)
        {
        case 1:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Ferran << " puntos de vida\n";
            Vida_Enemigo_1 = Vida_Enemigo_1 - Ferran;
            cout << "Luis se ha quedado con " << Vida_Enemigo_1 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;
        case 2:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Olmo << " puntos de vida\n";
            Vida_Enemigo_1 = Vida_Enemigo_1 - Olmo;
            cout << "Luis se ha quedado con " << Vida_Enemigo_1 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;
        case 3:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Koke << " puntos de vida\n";
            Vida_Enemigo_1 = Vida_Enemigo_1 - Koke;
            cout << "Luis se ha quedado con " << Vida_Enemigo_1 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;
        default:
            cout << "Este ataque no existe";
        }
    }
    else if (!enemigo01_vivo) {
        cout << "";
    }
    if ((eleccion == 2) && (enemigo02_vivo == true)) {
        cout << "Que ataque usaras? (1)Ferran (2)Olmo (3)Koke  ";
        cin >> respuesta;
        switch (respuesta) {

        case 1:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Ferran << " puntos de vida\n";
            vida_enemigo_2 = vida_enemigo_2 - Ferran;
            cout << "Enrique se ha quedado con " << vida_enemigo_2 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;

        case 2:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Olmo << " puntos de vida\n";
            vida_enemigo_2 = vida_enemigo_2 - Olmo;
            cout << "Enrique se ha quedado con " << vida_enemigo_2 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;
        case 3:
            cout << "\n";
            cout << "Tu ataque le ha hecho un dano de " << Koke << " puntos de vida\n";
            vida_enemigo_2 = vida_enemigo_2 - Koke;
            cout << "Enrique se ha quedado con " << vida_enemigo_2 << "puntos de vida\n";
            cout << "\n";
            da�o_random_enemigo = rand() % 2;
            Da�o_enemigo_2 = 10 + rand() % (5 - 15);
            vida_heroe = vida_heroe - Da�o_enemigo_2;
            cout << "Tu enemigo " << nombre_enemigo_2 << " te ha atacado y te ha hecho " << Da�o_enemigo_2 << " de da�o\n";
            cout << "Tus vida es de " << vida_heroe << " puntos de 100 que disponias\n";
            break;
        default:
            cout << "Este ataque no existe";
        }
    }
    else if (!enemigo02_vivo) {
        cout << "";

    }
}


int main() {

    srand(time(NULL));
    empezar();

    while ((enemigo01_vivo) || (enemigo02_vivo) && (heroe_vivo)) {
        eleccionEnemigo();

        AtaqueHeroe();
        enemigoVivo(enemigo01_vivo, nombre_enemigo_1);
        enemigoVivo(enemigo02_vivo, nombre_enemigo_2);


        if ((!enemigo01_vivo) && (!enemigo02_vivo)) {
            enemigo02_vivo = false;
            cout << "\n";
            cout << "����������������������HAS MATADO A TUS DOS ENEMIGOS, TE HAS PASADO EL JUEGO !!!!!!!!!!!!!!!!!!!!\n";
        }



        if (vida_heroe <= 0) {
            cout << "\n";
            cout << "GameOver";
            vida_heroe = 0;
            heroe_vivo = false;


        }
    }
}
